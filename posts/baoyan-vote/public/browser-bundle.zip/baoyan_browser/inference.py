"""Pure-Python inference of the frozen CatBoost model; no network or native libraries."""
import json
import math
import struct
from pathlib import Path
from . import exported_model
from .features import transform, validate_background

SPEC = json.loads((Path(__file__).parent / "feature-spec.json").read_text())
# CatBoost's Python export spells UTF-8 bytes as \xNN literals. Decode those
# keys back to Unicode so Chinese categories keep the native model's hashes.
exported_model.cat_features_hashes = {
    key.encode("latin1").decode("utf-8"): value
    for key, value in exported_model.cat_features_hashes.items()
}
NUMERIC = [key for key in SPEC["columns"] if key not in SPEC["categorical"]]
CLASSES = ["不行", "刚好", "OQ"]


def predict_features(features):
    # Native CatBoost quantizes float32 inputs. Match its boundary behavior.
    floats = [struct.unpack("f", struct.pack("f", features[key]))[0] for key in NUMERIC]
    cats = [features[key] for key in SPEC["categorical"]]
    logits = exported_model.apply_catboost_model_multi(floats, cats)
    weights = [math.exp(value - max(logits)) for value in logits]
    return [value / sum(weights) for value in weights]


def predict(background):
    errors = validate_background(background)
    if errors:
        raise ValueError("；".join(errors))
    probabilities = predict_features(transform(background))
    return {"probabilities": dict(zip(CLASSES, probabilities)),
            "prediction": CLASSES[max(range(3), key=probabilities.__getitem__)]}
