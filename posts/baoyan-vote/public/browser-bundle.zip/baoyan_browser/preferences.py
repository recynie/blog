"""Three-valued preference lookup shared by inference and training; no text parsing."""

def preference_state(target, kind, name):
    accepted = target.get('accepted_'+kind+'s', [])
    excluded = target.get('excluded_'+kind+'s', [])
    if name in target.get('uncertain_'+kind+'s', []) or (name in accepted and name in excluded):
        return 'unknown'
    return 'yes' if name in accepted else 'no' if name in excluded else 'unknown'
