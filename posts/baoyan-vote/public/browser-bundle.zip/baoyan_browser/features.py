"""Pure offline feature contract. Used unchanged by train and predict; no Jev imports."""
import hashlib
import json
import math
from pathlib import Path
from .schema import TIERS, PAPER_FIELDS, AWARD_FIELDS, SIGNALS
from .preferences import preference_state


MODEL_VERSION = 'mvp-10-quantities-only'
TIER_ORDER = {'211': 0, '末九': 1, '中九': 2, '华五': 3, '清北': 4}


def ordered_features(background):
    """Exact five input features selected in submission_ordinal; no tier inference."""
    tiers = set(background.get('target', {}).get('tiers', []))
    ordered = [TIER_ORDER[t] for t in tiers if t in TIER_ORDER]
    return {'ord_school': TIER_ORDER.get(background.get('school_tier'), float('nan')),
            'ord_target_min': min(ordered) if ordered else float('nan'),
            'ord_target_max': max(ordered) if ordered else float('nan'),
            'ord_target_mapped_count': len(ordered),
            'ord_target_unmapped_count': len(tiers) - len(ordered)}


def transform(background):
    b=background;target=b.get('target',{})
    f={'school_tier':b.get('school_tier','unknown'), 'research_state':b.get('research_state','unknown'),
       'awards_state':b.get('awards_state','unknown'), 'english_type':b.get('english_type','unknown'),
       'target_degree':target.get('degree','unknown'), 'target_advisor':target.get('advisor','unknown')}
    rank,total=b.get('rank'),b.get('total_students')
    f['rank_fraction']=rank/total if rank is not None and total else float('nan')
    f['total_students']=total if total is not None else float('nan')
    f['english_score']=b.get('english_score') if b.get('english_score') is not None else float('nan')
    for tier in TIERS: f['target_'+tier]=int(tier in target.get('tiers',[]))
    f['target_tier_count']=len(target.get('tiers',[]))
    for name in ['academic','professional','phd']:
        # Unknown and explicit no differ: use three-valued strings.
        f['degree_'+name]=preference_state(target,'degree',name)
    # Reject semantic-screening labels as model features. They are exclusion rules only.
    for name in SIGNALS:
        if name in ['custom_vote','hypothetical_background']: continue
        s=b.get('signals',{}).get(name,{})
        f['signal_'+name]={'known':'yes','explicit_no':'no'}.get(s.get('status'),'unknown')
        degree_signal={'academic_master':'academic','professional_master':'professional','direct_phd':'phd'}
        if name in degree_signal:f['signal_'+name]=preference_state(target,'degree',degree_signal[name])
    rfields=list(PAPER_FIELDS)
    for field in rfields:
        for value in PAPER_FIELDS[field]: f['r_'+field+'_'+value]=0.
    f['r_observed_items']=0.;f['r_unknown_quantity']=0.;f['r_accepted_lead']=0.;f['r_planned_present']=0.
    known={'r':0.,'a':0.}
    for item in b.get('research',[]):
        if not item.get('counting_eligible',True):continue
        if item.get('progress')=='planned' or item.get('future_only'): f['r_planned_present']=1.;continue
        n=item.get('quantity')
        if n is None:f['r_unknown_quantity']+=1;n=1  # Secure existence supplies a lower bound, never an exact imputed quantity.
        else:known['r']+=max(0.,float(n))
        n=max(0,float(n));f['r_observed_items']+=n
        for field in rfields:
            if item.get('kind')!='paper' and field not in ['kind','progress']:continue
            value=item.get(field,'unknown');key='r_'+field+'_'+value
            if key in f:f[key]+=n
        if item.get('kind')=='paper' and item.get('progress')=='accepted' and item.get('author') in ['first','cofirst']:
            f['r_accepted_lead']+=n
    for field,values in AWARD_FIELDS.items():
        for value in values:f['a_'+field+'_'+value]=0.
    f['a_observed_items']=0.;f['a_unknown_quantity']=0.;f['csp_score']=float('nan')
    for item in b.get('awards',[]):
        if item.get('planned') or not item.get('counting_eligible',True):continue
        if item.get('kind')=='csp' and item.get('score') is not None:
            old=f['csp_score'];f['csp_score']=max(0 if math.isnan(old) else old,float(item['score']))
        n=item.get('quantity')
        if n is None:f['a_unknown_quantity']+=1;n=1
        else:known['a']+=max(0.,float(n))
        f['a_observed_items']+=max(0,float(n))
        for field in AWARD_FIELDS:
            key='a_'+field+'_'+item.get(field,'unknown')
            if key in f:f[key]+=max(0,float(n))
    f.update(ordered_features(background))
    for prefix in ('r','a'):
        f[prefix+'_known_quantity_total']=known[prefix]
        f[prefix+'_unknown_quantity_item_count']=f[prefix+'_unknown_quantity']
    return f


def specification():
    sample=transform({})
    data={'version':MODEL_VERSION,'columns':list(sample),'categorical':[k for k,v in sample.items() if isinstance(v,str)],
          'numeric_missing':'NaN', 'count_cap':None,'prohibited':['id','votes','createdAt','editedAt','likeCount','commentCount','isLiked','myVote']}
    data['count_semantics']='Unbounded lower-bound aggregates for securely attributed actual achievements: known quantity, otherwise minimum one plus an unknown-quantity indicator. Separate known-quantity sums and unknown-quantity item counts; unknown is never an exact imputed quantity. Blocked entities contribute zero; confirmed future plans supply only a plan flag.'
    data['ordinal_inputs']={'tier_order':TIER_ORDER, 'unmapped':'NaN school/min/max; distinct target counts; C9, 双非, 四非 and unknown are not ordered'}
    data['implementation_sha256']={name:hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest() for name in ['features.py','schema.py','preferences.py','__init__.py']}
    data['sha256']=hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return data


def validate_background(b):
    errors=[]
    if b.get('school_tier','unknown') not in TIERS+['unknown']:errors.append('本科学校层次无效')
    target=b.get('target',{})
    if not target.get('tiers') or any(t not in TIERS for t in target['tiers']):errors.append('至少选择一个有效目标层次')
    rank,total=b.get('rank'),b.get('total_students')
    if (rank is None)!=(total is None):errors.append('排名与人数需同时填写或同时未知')
    if rank is not None and (not isinstance(rank,(int,float)) or not isinstance(total,(int,float)) or not math.isfinite(rank) or not math.isfinite(total) or rank<1 or total<rank or rank!=int(rank) or total!=int(total)):
        errors.append('排名/人数需为正整数，且排名不超过人数')
    limits={'六级':710,'四级':710,'雅思':9,'托福':120}
    et=b.get('english_type','unknown');score=b.get('english_score')
    if et not in ['unknown',*limits]:errors.append('英语类型无效')
    if score is not None and (et not in limits or not isinstance(score,(int,float)) or not math.isfinite(score) or not 0<=score<=limits[et]):errors.append('英语分数与考试类型不匹配')
    for collection,fields,state in [('research',PAPER_FIELDS,'research_state'),('awards',AWARD_FIELDS,'awards_state')]:
        if b.get(state,'unknown') not in ['unknown','none','present']:errors.append('成果存在状态无效')
        if b.get(state)=='none' and any(i.get('counting_eligible',True) and not i.get('planned') and not i.get('future_only') and i.get('progress')!='planned' for i in b.get(collection,[])):
            errors.append('明确没有当前成果时不能同时添加实际成果条目；未来计划可单独记录')
        for item in b.get(collection,[]):
            for key,values in fields.items():
                if item.get(key,'unknown' if 'unknown' in values else values[0]) not in values:errors.append(f'{collection}.{key}类别无效')
            score=item.get('score')
            if item.get('kind')=='csp' and score is not None and (not isinstance(score,(int,float)) or not math.isfinite(score) or not 0<=score<=500 or score!=int(score)):errors.append('CSP成绩须为0–500的整数或未知')
            n=item.get('quantity')
            if n is not None and (not isinstance(n,(int,float)) or not math.isfinite(n) or n<1 or n>100 or n!=int(n)):errors.append('成果数量须为1–100的整数或未知')
    for key in ['accepted_degrees','excluded_degrees']:
        if any(v not in ['academic','professional','phd'] for v in target.get(key,[])):errors.append('学位集合类别无效')
    if set(target.get('accepted_degrees',[])) & set(target.get('excluded_degrees',[])):errors.append('同一学位不能同时接受与排除')
    return errors
