"""Small shared vocabulary. Original website tags and inferred attributes stay separate."""
from . import VERSION
CLASSES = ['不行', '刚好', 'OQ']
TIERS = ['清北', '华五', 'C9', '中九', '末九', '211', '双非', '四非']
STATES = ['unknown', 'none', 'present']
STATUSES = ['known', 'explicit_no', 'missing', 'ambiguous', 'not_applicable']
PAPER_FIELDS = {
    'kind': ['unknown', 'paper', 'project', 'patent', 'software', 'other'],
    'carrier': ['unknown', 'conference', 'journal'],
    'ccf': ['unknown', 'CCF-A', 'CCF-B', 'CCF-C', 'CCF-None', '顶会'],
    'partition_system': ['unknown', 'CAS', 'JCR'],
    'partition': ['unknown', '1', '2', '3', '4'],
    'author': ['unknown', 'first', 'cofirst', 'second', 'later'],
    'progress': ['unknown', 'planned', 'ongoing', 'submitted', 'accepted'],
    'presentation': ['unknown', 'Poster', 'Spotlight', 'Oral'],
    'honor': ['unknown', 'BestPaper', 'BestPaperCandidate'],
}
AWARD_FIELDS = {
    'kind': ['unknown', 'competition', 'scholarship', 'project', 'csp', 'other'],
    'family': ['unknown', 'xcpc', 'programming', 'modeling', 'math', 'engineering_security', 'innovation', 'other'],
    'scope': ['unknown', '省级', '国家', '国际', '校级'],
    'grade': ['unknown', '一等奖', '二等奖', '三等奖', 'gold', 'silver', 'bronze', 'MCM_O', 'MCM_F', 'MCM_M', 'MCM_H', 'other'],
}
SIGNALS = {
    'research_experience': 'Actual research experience, including research without any publication; a future plan alone is not actual experience.',
    'course_project': 'Completed or ongoing coursework engineering or course-design project.',
    'innovation_project': 'Participation in an undergraduate innovation training project (大创/国创/省创).',
    'planned_paper': 'A hypothetical or planned future paper, not an already submitted or accepted paper.',
    'internship': 'Wants permission to take internships during graduate study.',
    'title_priority': 'Explicitly prioritizes university prestige; a university name alone does not establish this.',
}
LABEL_DICTIONARY = {'version': VERSION, 'classes': CLASSES, 'school_tiers': TIERS,
    'existence_states': STATES, 'information_statuses': STATUSES,
    'research_fields': PAPER_FIELDS, 'award_fields': AWARD_FIELDS, 'signals': SIGNALS,
    'provenance': {'website': 'Copy structured tags directly; retain original objects.',
        'supplement': 'Jev choices and confidence, linked to a source field and request hash; no semantic regex overrides.',
        'new_item': 'Jev identifies an independently additional achievement; unresolved overlap is not counted.'},
    'quantity': 'Explicit total selected by Jev; unknown stays null. Features use capped lower bounds plus unknown-count indicators.',
    'target': 'Website tier retained separately. Only explicit accepted supplemental tiers enter factual sets; conditional/ambiguous statements remain unresolved.'}


def blank_item(fields):
    return {k: 'unknown' for k in fields}
