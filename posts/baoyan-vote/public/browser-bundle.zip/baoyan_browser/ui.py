"""Structured UI helpers. Pure local form -> shared background schema."""
from .schema import PAPER_FIELDS, AWARD_FIELDS, SIGNALS

LABELS={'unknown':'未知 / 未提及','none':'明确没有','present':'有','yes':'明确是','no':'明确否','paper':'论文','project':'项目经历',
        'patent':'专利','software':'软著','other':'其他','conference':'会议','journal':'期刊',
        'first':'第一 / 学生一作','cofirst':'共同一作',
        'second':'第二作者','later':'第三及以后','planned':'未来计划 / 设想','ongoing':'在研 / 在写','submitted':'在投',
        'accepted':'已录用 / 发表','competition':'竞赛','scholarship':'奖学金','csp':'CSP成绩',
        'xcpc':'ICPC / CCPC','programming':'其他编程赛事','modeling':'数学建模','math':'数学竞赛',
        'engineering_security':'工程 / 机器人 / 安全','innovation':'创新创业 / 项目设计',
        'gold':'金牌','silver':'银牌','bronze':'铜牌'}
FIELD_LABELS={'kind':'成果类型','carrier':'载体','ccf':'已有CCF标签',
              'partition_system':'期刊分区体系','partition':'分区','author':'作者角色','progress':'进度',
              'presentation':'展示形式','honor':'论文荣誉','family':'赛事族','scope':'范围','grade':'原始奖级'}
SIGNAL_LABELS={'research_experience':'明确有科研经历','course_project':'课程项目','innovation_project':'大创 / 国创 / 省创',
               'planned_paper':'未来计划论文','internship':'要求允许实习','title_priority':'明确优先院校名气'}


def dropdown(mo,values,label,default=None):
    options={LABELS.get(v,v):v for v in values if v!='unknown'}
    selected=default if default is not None else ('unknown' if 'unknown' in values else values[0])
    return mo.ui.dropdown(options,value=None if selected=='unknown' else LABELS.get(selected,selected),label=label,allow_select_none=True)


def item_form(mo,kind,values=None):
    fields=PAPER_FIELDS if kind=='research' else AWARD_FIELDS
    values=values or {}
    controls={k:dropdown(mo,v,FIELD_LABELS.get(k,k),default=values.get(k)) for k,v in fields.items()}
    controls['quantity']=mo.ui.number(step=1,value=values.get('quantity'),label='数量（1–100）')
    if kind=='awards':
        controls['planned']=mo.ui.checkbox(value=values.get('planned',False),label='未来计划 / 设想')
        controls['score']=mo.ui.number(step=1,value=values.get('score'),label='CSP分数（0–500）')
    return mo.ui.dictionary(controls)


def entry_cards(mo,kind,rows,set_rows):
    """Rebuild on add/delete only, snapshotting values before changing the list."""
    title='科研' if kind=='research' else '奖项 / 测评'
    forms=[item_form(mo,kind,row) for row in rows]
    buttons=[mo.ui.button(label=f'删除{title} {i+1}',on_click=lambda _, index=i: set_rows([f.value for j,f in enumerate(forms) if j!=index])) for i in range(len(forms))]
    cards=[mo.accordion({f'{title} {i+1}':mo.vstack([form, buttons[i]])}) for i,form in enumerate(forms)]
    add=mo.ui.button(label=f'＋ 添加{title}条目',on_click=lambda _: set_rows([*[f.value for f in forms], {}]))
    # Keep strong references: rendered HTML does not retain its UI elements.
    return forms,[*buttons,add],mo.vstack([*cards,add])


def structured_background(basic,target,research,awards,signals):
    def items(rows):
        output=[]
        for row in rows:
            item={k:('unknown' if v is None and k in {*PAPER_FIELDS, *AWARD_FIELDS} else v) for k,v in row.items()}
            if 'score' in row:item['score']=row['score'] if item['kind']=='csp' else None
            output.append(item)
        return output
    research,awards=items(research),items(awards)
    def state(rows,key):
        if any(r.get('progress')!='planned' and not r.get('planned') for r in rows):
            return 'present'
        return basic.get(key) or 'unknown'
    signals=dict(signals)
    if any(r.get('kind')=='paper' and r.get('progress')=='planned' for r in research):
        signals['planned_paper']='yes'
    if any(r.get('kind')=='paper' and r.get('progress') in ['ongoing','submitted','accepted'] for r in research):
        signals['research_experience']='yes'
    return {'school_tier':basic['school_tier'] or 'unknown','rank':basic['rank'],
            'total_students':basic['total_students'],
            'english_type':basic['english_type'] or 'unknown','english_score':basic['english_score'],
            'research_state':state(research,'research_state'),'awards_state':state(awards,'awards_state'),
            'research':research,'awards':awards,
            'signals':{k:{'status':{'yes':'known','no':'explicit_no','unknown':'missing'}[signals.get(k) or 'unknown']} for k in SIGNALS},
            'target':{'tiers':target['tiers'],'degree':target['degree'] or 'unknown','advisor':target['advisor'] or 'unknown',
                      'accepted_degrees':target['accepted_degrees'],'excluded_degrees':target['excluded_degrees'],
                      'uncertain_degrees':target['uncertain_degrees']}}
