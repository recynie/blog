"""Shared, local-first baoyan vote pipeline."""
VERSION = 'mvp-8'
